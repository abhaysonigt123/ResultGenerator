import { useState } from "react";
import { Home, User, ChevronRight } from "lucide-react";

export default function Sidebar({ onSelectClass }) {
  const [open, setOpen] = useState(true);

  const classes = [
    "Class LKG",
    "Class UKG",
    "Class KG1",
    "Class KG2",
    "Class 1st",
    "Class 2nd",
    "Class 3",
    "Class 4",
    "Class 5",
    "Class 6",
    "Class 7",
    "Class 8",
    "Class 9",
    "Class 11 Bio/Math's",
    "Class 11 Arts",
  ];

  return (
    <aside className="w-64 bg-gray-800 text-white h-screen flex flex-col">
      {/* Dashboard Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-800 flex items-center px-4 py-3 font-semibold text-sm shadow">
        <Home className="mr-2" size={16} /> Dashboard
      </div>

      {/* Student Section */}
      <div
        className="bg-gradient-to-r from-green-700 to-green-600 px-4 py-2 flex justify-between items-center cursor-pointer text-sm font-medium"
        onClick={() => setOpen(!open)}
      >
        <div className="flex items-center">
          <User className="mr-2" size={16} /> Student
        </div>
      </div>

      {/* Class List */}
      {open && (
        <div className="flex-1 overflow-y-auto">
          {classes.map((className, index) => (
            <button
              key={index}
              onClick={() => onSelectClass(className)}
              className="w-full text-left text-sm px-5 py-2 hover:bg-gray-700 transition flex justify-between items-center"
            >
              <span>{className}</span>
              <ChevronRight size={14} />
            </button>
          ))}
        </div>
      )}

      {/* Bottom Green Section */}
      <div className="bg-green-200 h-16"></div>
    </aside>
  );
}
