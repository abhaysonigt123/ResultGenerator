import React, { useState } from 'react';


export default function StudentForm({ student, onSave, onCancel }) {
const [formData, setFormData] = useState(student);


const handleChange = (e) => {
setFormData({ ...formData, [e.target.name]: e.target.value });
};


const handleSubmit = (e) => {
e.preventDefault();
onSave(formData);
};
return (
<div className="bg-white rounded-xl shadow-md p-6 max-w-2xl mx-auto">
<h2 className="text-xl font-semibold text-gray-700 mb-4">Edit Student</h2>
<form onSubmit={handleSubmit} className="space-y-4">
<div className="grid grid-cols-2 gap-4">
<div>
<label className="block text-sm font-medium text-gray-600">Name</label>
<input
type="text"
name="name"
value={formData.name}
onChange={handleChange}
className="w-full border rounded-lg p-2 mt-1 focus:ring focus:ring-blue-200"
/>
</div>
<div>
<label className="block text-sm font-medium text-gray-600">Roll No</label>
<input
type="text"
name="rollNo"
value={formData.rollNo}
onChange={handleChange}
className="w-full border rounded-lg p-2 mt-1 focus:ring focus:ring-blue-200"
/>
</div>
<div>
<label className="block text-sm font-medium text-gray-600">Class</label>
<input
type="text"
name="class"
value={formData.class}
onChange={handleChange}
className="w-full border rounded-lg p-2 mt-1"
/>
</div>
<div>
<label className="block text-sm font-medium text-gray-600">Section</label>
<input
type="text"
name="section"
value={formData.section}
onChange={handleChange}
className="w-full border rounded-lg p-2 mt-1"
/>
</div>
<div>
<label className="block text-sm font-medium text-gray-600">Age</label>
<input
type="number"
name="age"
value={formData.age}
onChange={handleChange}
className="w-full border rounded-lg p-2 mt-1"
/>
</div>
</div>
<div className="flex justify-end space-x-3 pt-4">
<button
type="button"
onClick={onCancel}
className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg"
>
Cancel
</button>
<button
type="submit"
className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg"
>
Save
</button>
</div>
</form>
</div>
);
}