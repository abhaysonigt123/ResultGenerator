import React, { useState, useMemo } from "react";

/**
 * EditStudent.jsx
 * - inline page (not modal)
 * - Tab switching between Student Details | Term-1 | Term-2 | Marksheet
 * - Term inputs feed marksheet (read-only)
 * - Save & Print: calls onSave(updatedStudent) then window.print()
 *
 * Usage: <EditStudent student={s} onBack={fn} onSave={fn} />
 */

export default function EditStudent({ student, onBack, onSave, classNameName = "Class 3" }) {
  // basic student info
  const [info, setInfo] = useState({
    id: student.id,
    name: student.name || "",
    admission: student.admission || "",
    roll: student.roll || "",
    session: student.session || "2024-25",
    className: student.class || classNameName.replace("Class", "").trim(),
    section: student.section || "",
    dob: student.dob || "",
    dobWords: student.dobWords || "",
    motherName: student.motherName || "",
    fatherName: student.fatherName || "",
    date: student.date || "",
  });

  // structure for term marks: list of subjects; each subject object has columns
  const subjects = useMemo(() => ["English", "Hindi", "Mathematics", "Environmental Studies"], []);
  const initialTerm = () =>
    subjects.map((sub) => ({
      subject: sub,
      periodic: "", // out of 10
      notebook: "", // out of 5
      enrichment: "", // out of 5
      halfYearly: "", // out of 80 for term1 OR annual for term2 (80)
    }));

  const [term1, setTerm1] = useState(student.term1 ? student.term1 : initialTerm());
  const [term2, setTerm2] = useState(student.term2 ? student.term2 : initialTerm());

  const [coScholastic, setCoScholastic] = useState(
    student.coScholastic || { workEdu: "B", artEdu: "B", health: "B", discipline: "B", classRemark: "VERY GOOD", attendance: "186/214", result: "PASS" }
  );

  const [activeTab, setActiveTab] = useState("details"); // 'details' | 'term1' | 'term2' | 'marksheet'

  // helpers to change term rows
  function updateTerm(setter, list, index, field, value) {
    const copy = list.map((r) => ({ ...r }));
    copy[index][field] = value;
    setter(copy);
  }

  // compute marks for a term: returns array of per-subject totals and overall total
  function computeTermTotals(termList) {
    const perSubject = termList.map((r) => {
      const p = Number(r.periodic) || 0;
      const n = Number(r.notebook) || 0;
      const e = Number(r.enrichment) || 0;
      const h = Number(r.halfYearly) || 0;
      const total = p + n + e + h;
      return { subject: r.subject, total, breakdown: { periodic: p, notebook: n, enrichment: e, half: h } };
    });
    const grand = perSubject.reduce((s, x) => s + x.total, 0);
    return { perSubject, grand };
  }

  const t1 = computeTermTotals(term1);
  const t2 = computeTermTotals(term2);

  // Marksheet calculations:
  const subjectsCount = subjects.length;
  const maxPerSubjectTerm = 100; // as per your design Term each 100
  const totalMax = maxPerSubjectTerm * subjectsCount * 1; // per term
  const grandTotalBoth = t1.grand + t2.grand;
  const maxBoth = totalMax * 2;
  const percentage = grandTotalBoth === 0 ? 0 : Number(((grandTotalBoth / maxBoth) * 100).toFixed(2));

  function gradeFromPercentage(p) {
    if (p >= 91) return "A1";
    if (p >= 81) return "A2";
    if (p >= 71) return "B1";
    if (p >= 61) return "B2";
    if (p >= 51) return "C1";
    if (p >= 41) return "C2";
    if (p >= 33) return "D";
    return "E";
  }

  const overallGrade = gradeFromPercentage(percentage);

  // Save (updates student object and call onSave)
  function handleSaveAndPrint() {
    const updatedStudent = {
      ...student,
      ...info,
      term1,
      term2,
      coScholastic,
      marksSummary: { t1, t2, grandTotalBoth, percentage, overallGrade },
    };
    if (onSave) onSave(updatedStudent);

    // print only the result area: use CSS print utilities (Tailwind print:) or fallback to window.print
    setTimeout(() => {
      window.print();
    }, 200);
  }

  return (
    <div className="min-h-screen bg-green-100 p-3">
      {/* top header with back */}
      <div className="flex justify-between items-center mb-3">
        <div>
          <h2 className="text-lg font-semibold text-green-900">Manage {classNameName}</h2>
        </div>
        <div className="flex gap-2">
          <button onClick={onBack} className="bg-orange-400 text-white px-3 py-1 rounded">Back</button>
          <button onClick={() => { setActiveTab("marksheet"); }} className="bg-gray-200 px-3 py-1 rounded">View Marksheet</button>
        </div>
      </div>

      {/* tabs */}
      <div className="flex gap-2 mb-3 print:hidden">
        <button onClick={() => setActiveTab("details")} className={`px-3 py-2 rounded ${activeTab === "details" ? "bg-green-200 font-semibold" : "bg-white"}`}>Student Details</button>
        <button onClick={() => setActiveTab("term1")} className={`px-3 py-2 rounded ${activeTab === "term1" ? "bg-green-200 font-semibold" : "bg-white"}`}>Term-1</button>
        <button onClick={() => setActiveTab("term2")} className={`px-3 py-2 rounded ${activeTab === "term2" ? "bg-green-200 font-semibold" : "bg-white"}`}>Term-2</button>
        <button onClick={() => setActiveTab("marksheet")} className={`px-3 py-2 rounded ${activeTab === "marksheet" ? "bg-green-200 font-semibold" : "bg-white"}`}>Current Result Marksheet</button>
      </div>

      {/* CONTENT AREA */}
      <div className="bg-white border border-gray-200 p-4 rounded">
        {/* Student Details */}
        {activeTab === "details" && (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setActiveTab("term1"); }}>
            <div className="flex justify-between items-start gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium">Student Name *</label>
                <input className="w-full border p-2 rounded" name="name" value={info.name} onChange={(e) => setInfo({ ...info, name: e.target.value })} required />
              </div>
              <div className="w-60">
                <label className="block text-sm font-medium">Admission No *</label>
                <input className="w-full border p-2 rounded" name="admission" value={info.admission} onChange={(e) => setInfo({ ...info, admission: e.target.value })} required />
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium">Roll No *</label>
                <input className="w-full border p-2 rounded" name="roll" value={info.roll} onChange={(e) => setInfo({ ...info, roll: e.target.value })} required />
              </div>
              <div>
                <label className="block text-sm font-medium">Session *</label>
                <input className="w-full border p-2 rounded" name="session" value={info.session} onChange={(e) => setInfo({ ...info, session: e.target.value })} />
              </div>
              <div>
                <label className="block text-sm font-medium">Class *</label>
                <select className="w-full border p-2 rounded" value={info.className} onChange={(e) => setInfo({ ...info, className: e.target.value })}>
                  {Array.from({ length: 12 }).map((_, i) => <option key={i}>{i + 1}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium">Section</label>
                <select className="w-full border p-2 rounded" value={info.section} onChange={(e) => setInfo({ ...info, section: e.target.value })}>
                  <option value="">section</option>
                  <option>A</option>
                  <option>B</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium">Date of Birth *</label>
                <input type="date" className="w-full border p-2 rounded" value={info.dob} onChange={(e) => setInfo({ ...info, dob: e.target.value })} />
                <div className="text-xs text-red-500 mt-1">Date-format : dd/mm/yyyy</div>
              </div>
              <div>
                <label className="block text-sm font-medium">DOB (in words)</label>
                <input className="w-full border p-2 rounded" value={info.dobWords} onChange={(e) => setInfo({ ...info, dobWords: e.target.value })} />
              </div>
              <div />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium">Mother's Name</label>
                <input className="w-full border p-2 rounded" value={info.motherName} onChange={(e) => setInfo({ ...info, motherName: e.target.value })} />
              </div>
              <div>
                <label className="block text-sm font-medium">Father's / Guardian's Name</label>
                <input className="w-full border p-2 rounded" value={info.fatherName} onChange={(e) => setInfo({ ...info, fatherName: e.target.value })} />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={onBack} className="px-4 py-2 bg-gray-200 rounded">Back</button>
              <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded">Next (Term-1)</button>
            </div>
          </form>
        )}

        {/* TERM-1 */}
        {activeTab === "term1" && (
          <div>
            <h4 className="font-semibold mb-2">Term-1 (100)</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border p-2">Subject</th>
                    <th className="border p-2">Periodic Test<br />(10)</th>
                    <th className="border p-2">Note Book<br />(5)</th>
                    <th className="border p-2">Subject Enrichment<br />(5)</th>
                    <th className="border p-2">Half Yearly Exam<br />(80)</th>
                    <th className="border p-2">Marks Obtained</th>
                  </tr>
                </thead>
                <tbody>
                  {term1.map((row, idx) => {
                    const p = Number(row.periodic) || 0;
                    const n = Number(row.notebook) || 0;
                    const e = Number(row.enrichment) || 0;
                    const h = Number(row.halfYearly) || 0;
                    const total = p + n + e + h;
                    return (
                      <tr key={idx} className="border-b">
                        <td className="p-2 border">{row.subject}</td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.periodic} onChange={(e) => updateTerm(setTerm1, term1, idx, "periodic", e.target.value)} />
                        </td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.notebook} onChange={(e) => updateTerm(setTerm1, term1, idx, "notebook", e.target.value)} />
                        </td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.enrichment} onChange={(e) => updateTerm(setTerm1, term1, idx, "enrichment", e.target.value)} />
                        </td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.halfYearly} onChange={(e) => updateTerm(setTerm1, term1, idx, "halfYearly", e.target.value)} />
                        </td>
                        <td className="p-2 border text-center">{total}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Co-scholastic */}
            <div className="mt-3 border p-3 bg-gray-50">
              <h5 className="font-medium">Co-Scholastic Areas Term-1 (A-C)</h5>
              <div className="grid grid-cols-2 gap-3 mt-2">
                <label>Work Education (Grade)
                  <select className="w-full border p-2 rounded" value={coScholastic.workEdu} onChange={(e) => setCoScholastic({ ...coScholastic, workEdu: e.target.value })}>
                    <option>B</option><option>A</option><option>C</option>
                  </select>
                </label>
                <label>Art Education (Grade)
                  <select className="w-full border p-2 rounded" value={coScholastic.artEdu} onChange={(e) => setCoScholastic({ ...coScholastic, artEdu: e.target.value })}>
                    <option>B</option><option>A</option><option>C</option>
                  </select>
                </label>
                <label>Health & Physical Education
                  <select className="w-full border p-2 rounded" value={coScholastic.health} onChange={(e) => setCoScholastic({ ...coScholastic, health: e.target.value })}>
                    <option>B</option><option>A</option><option>C</option>
                  </select>
                </label>
              </div>
            </div>

            <div className="mt-3 flex justify-between">
              <button onClick={() => setActiveTab("details")} className="px-4 py-2 bg-gray-200 rounded">Back</button>
              <button onClick={() => setActiveTab("term2")} className="px-4 py-2 bg-green-600 text-white rounded">Next (Term-2)</button>
            </div>
          </div>
        )}

        {/* TERM-2 (similar layout) */}
        {activeTab === "term2" && (
          <div>
            <h4 className="font-semibold mb-2">Term-2 (100)</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border p-2">Subject</th>
                    <th className="border p-2">Periodic Test<br />(10)</th>
                    <th className="border p-2">Note Book<br />(5)</th>
                    <th className="border p-2">Subject Enrichment<br />(5)</th>
                    <th className="border p-2">Annual Exam<br />(80)</th>
                    <th className="border p-2">Marks Obtained</th>
                  </tr>
                </thead>
                <tbody>
                  {term2.map((row, idx) => {
                    const p = Number(row.periodic) || 0;
                    const n = Number(row.notebook) || 0;
                    const e = Number(row.enrichment) || 0;
                    const h = Number(row.halfYearly) || 0;
                    const total = p + n + e + h;
                    return (
                      <tr key={idx} className="border-b">
                        <td className="p-2 border">{row.subject}</td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.periodic} onChange={(e) => updateTerm(setTerm2, term2, idx, "periodic", e.target.value)} />
                        </td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.notebook} onChange={(e) => updateTerm(setTerm2, term2, idx, "notebook", e.target.value)} />
                        </td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.enrichment} onChange={(e) => updateTerm(setTerm2, term2, idx, "enrichment", e.target.value)} />
                        </td>
                        <td className="p-2 border">
                          <input className="w-full border p-1 rounded" value={row.halfYearly} onChange={(e) => updateTerm(setTerm2, term2, idx, "halfYearly", e.target.value)} />
                        </td>
                        <td className="p-2 border text-center">{total}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-3 border p-3 bg-gray-50">
              <h5 className="font-medium">Co-Scholastic Areas Term-2 (A-C)</h5>
              <div className="grid grid-cols-2 gap-3 mt-2">
                <label>Work Education (Grade)
                  <select className="w-full border p-2 rounded" value={coScholastic.workEdu} onChange={(e) => setCoScholastic({ ...coScholastic, workEdu: e.target.value })}>
                    <option>B</option><option>A</option><option>C</option>
                  </select>
                </label>
                <label>Art Education (Grade)
                  <select className="w-full border p-2 rounded" value={coScholastic.artEdu} onChange={(e) => setCoScholastic({ ...coScholastic, artEdu: e.target.value })}>
                    <option>B</option><option>A</option><option>C</option>
                  </select>
                </label>
                <label>Health & Physical Education
                  <select className="w-full border p-2 rounded" value={coScholastic.health} onChange={(e) => setCoScholastic({ ...coScholastic, health: e.target.value })}>
                    <option>B</option><option>A</option><option>C</option>
                  </select>
                </label>
              </div>
            </div>

            <div className="mt-3 flex justify-between">
              <button onClick={() => setActiveTab("term1")} className="px-4 py-2 bg-gray-200 rounded">Back</button>
              <button onClick={() => setActiveTab("marksheet")} className="px-4 py-2 bg-green-600 text-white rounded">Show Marksheet</button>
            </div>
          </div>
        )}

        {/* MARKSHEET (read-only) */}
        {activeTab === "marksheet" && (
          <div id="printableReport">
            <h4 className="font-semibold mb-2">Current Result Marksheet | Marksheet Status : <span className="text-green-600 font-semibold">Completed</span></h4>

            <div className="overflow-x-auto border">
              <table className="w-full text-sm border-collapse">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-2 border">Subject</th>
                    <th className="p-2 border text-center">T1 Marks</th>
                    <th className="p-2 border text-center">T2 Marks</th>
                    <th className="p-2 border text-center">Average</th>
                    <th className="p-2 border text-center">Grade</th>
                  </tr>
                </thead>
                <tbody>
                  {subjects.map((sub, idx) => {
                    const s1 = t1.perSubject[idx] ? t1.perSubject[idx].total : 0;
                    const s2 = t2.perSubject[idx] ? t2.perSubject[idx].total : 0;
                    const avg = Math.round(((s1 + s2) / 2) * 100) / 100;
                    return (
                      <tr key={idx} className="border-b">
                        <td className="p-2 border">{sub}</td>
                        <td className="p-2 border text-center">{s1}</td>
                        <td className="p-2 border text-center">{s2}</td>
                        <td className="p-2 border text-center">{avg}</td>
                        <td className="p-2 border text-center">{gradeFromPercentage((avg / 100) * 100)}</td>
                      </tr>
                    );
                  })}

                  <tr>
                    <td className="p-2 border font-semibold">PERCENTAGE</td>
                    <td className="p-2 border text-center font-semibold">{percentage}%</td>
                    <td className="p-2 border text-center font-semibold">OVER ALL GRADE</td>
                    <td className="p-2 border text-center font-semibold">{overallGrade}</td>
                    <td className="p-2 border text-center font-semibold">GRAND TOTAL: {grandTotalBoth}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* co-scholastic + remarks */}
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="border p-3">
                <h5 className="font-semibold mb-2">Co-Scholastic Areas</h5>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <div>Work Education</div><div>{coScholastic.workEdu}</div>
                  </div>
                  <div className="flex justify-between">
                    <div>Art Education</div><div>{coScholastic.artEdu}</div>
                  </div>
                  <div className="flex justify-between">
                    <div>Health & Physical Education</div><div>{coScholastic.health}</div>
                  </div>
                </div>
              </div>

              <div className="border p-3">
                <h5 className="font-semibold mb-2">Remarks & Attendance</h5>
                <div className="space-y-2">
                  <div><strong>Class Teacher's Remark:</strong> {coScholastic.classRemark}</div>
                  <div><strong>Attendance:</strong> {coScholastic.attendance}</div>
                  <div><strong>Result:</strong> {coScholastic.result}</div>
                </div>
              </div>
            </div>

            {/* Save & Print */}
            <div className="flex justify-center mt-6 print:hidden">
              <button onClick={handleSaveAndPrint} className="bg-green-600 text-white px-4 py-2 rounded">Save & Print</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
