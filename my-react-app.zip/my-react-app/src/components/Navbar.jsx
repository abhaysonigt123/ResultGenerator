import { LogOut, Settings } from "lucide-react";

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between px-6 py-3 bg-[#d6e8a3] border-b-4 border-green-700 shadow-sm">
      <h1 className="text-2xl font-semibold text-red-600">
        Result Generate Software
      </h1>

      <div className="flex items-center space-x-5 text-green-700 text-sm font-medium">
        <button className="flex items-center space-x-1 hover:text-green-900 transition cursor-pointer">
          <Settings size={16} />
          <span>My Profile</span>
        </button>

        <button className="flex items-center space-x-1 hover:text-green-900 transition cursor-pointer">
          <LogOut size={16} />
          <span>Logout</span>
        </button>
      </div>
    </nav>
  );
}
