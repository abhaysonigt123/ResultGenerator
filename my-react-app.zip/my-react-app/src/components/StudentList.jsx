import React, { useState } from "react";
import { Pencil, Trash2, Link2, Plus, X } from "lucide-react";
import EditStudent from "./EditStudent";

export default function StudentList({ classNameName }) {
  const initialData = {
    "Class LKG": [
      { name: "Riya Sharma", roll: "101", admission: "R-0101", section: "A", date: "12-Jan-2025" },
      { name: "Aarav Mehta", roll: "102", admission: "R-0102", section: "A", date: "12-Jan-2025" },
    ],
    "Class UKG": [
      { name: "Ishika Singh", roll: "201", admission: "R-0201", section: "A", date: "15-Jan-2025" },
      { name: "Vivaan Patel", roll: "202", admission: "R-0202", section: "A", date: "15-Jan-2025" },
    ],
    "Class 1st": [
      { name: "Anaya Verma", roll: "301", admission: "R-0301", section: "A", date: "18-Jan-2025" },
      { name: "Kabir Jain", roll: "302", admission: "R-0302", section: "A", date: "18-Jan-2025" },
    ],
    "Class 2nd": [
      { name: "Siya Thakur", roll: "401", admission: "R-0401", section: "A", date: "20-Jan-2025" },
      { name: "Aditya Rao", roll: "402", admission: "R-0402", section: "A", date: "20-Jan-2025" },
    ],
    "Class 3": [{ name: "Yuvani Choure", roll: "339", admission: "R-0243", section: "A", date: "24-Dec-2024" }, { name: "Yashika Bherua", roll: "338", admission: "R-0338", section: "A", date: "24-Dec-2024" }, { name: "Virat Choudhary", roll: "337", admission: "R-0234", section: "A", date: "24-Dec-2024" }, { name: "Vidhika Tayade", roll: "336", admission: "R-0242", section: "A", date: "24-Dec-2024" }, { name: "Vedansh Vishwakarma", roll: "335", admission: "R-0295", section: "A", date: "24-Dec-2024" }, { name: "Vansh Sahu", roll: "334", admission: "R-0225", section: "A", date: "24-Dec-2024" }, { name: "Trishant Bamne", roll: "333", admission: "R-0147", section: "A", date: "24-Dec-2024" }, { name: "Tanvi Meena", roll: "332", admission: "R-0311", section: "A", date: "24-Dec-2024" }, { name: "Tanishqa Namdeo", roll: "331", admission: "R-0229", section: "A", date: "24-Dec-2024" }, { name: "Shourya Dongre", roll: "330", admission: "R-0241", section: "A", date: "23-Dec-2024" },],
    "Class 4": [
      { name: "Aanya Dubey", roll: "501", admission: "R-0501", section: "A", date: "25-Jan-2025" },
    ],
    "Class 5": [
      { name: "Devansh Tiwari", roll: "601", admission: "R-0601", section: "A", date: "28-Jan-2025" },
    ],
    "Class 6": [
      { name: "Mihika Sharma", roll: "701", admission: "R-0701", section: "A", date: "30-Jan-2025" },
    ],
    "Class 7": [
      { name: "Kritika Sen", roll: "801", admission: "R-0801", section: "A", date: "01-Feb-2025" },
    ],
    "Class 8": [
      { name: "Tanish Jain", roll: "901", admission: "R-0901", section: "A", date: "05-Feb-2025" },
    ],
    "Class 9": [
      { name: "Anshika Gupta", roll: "1001", admission: "R-1001", section: "A", date: "10-Feb-2025" },
    ],
    "Class 11 Bio/Math's": [
      { name: "Rudra Sharma", roll: "1101", admission: "R-1101", section: "A", date: "15-Feb-2025" },
    ],
    "Class 11 Arts": [
      { name: "Jhanvi Sahu", roll: "1201", admission: "R-1201", section: "A", date: "18-Feb-2025" },
    ],
  };


  const [studentData, setStudentData] = useState(initialData);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditComponent, setShowEditComponent] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [newStudent, setNewStudent] = useState({
    name: "",
    roll: "",
    admission: "",
    section: "",
    date: "",
  });
  const [currentPage, setCurrentPage] = useState(1);

  const students = studentData[classNameName] || [];
  const itemsPerPage = 10;
  const totalPages = Math.ceil(students.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentStudents = students.slice(startIndex, startIndex + itemsPerPage);

  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.roll || !newStudent.admission || !newStudent.section) {
      alert("Please fill all fields!");
      return;
    }

    const newEntry = {
      ...newStudent,
      date:
        newStudent.date ||
        new Date().toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        }),
    };

    const updatedStudents = [...students, newEntry];
    setStudentData({ ...studentData, [classNameName]: updatedStudents });
    setShowAddModal(false);
    setNewStudent({ name: "", roll: "", admission: "", section: "", date: "" });
  };

  const handleDelete = (index) => {
    const updated = [...students];
    updated.splice(startIndex + index, 1);
    setStudentData({ ...studentData, [classNameName]: updated });
  };

  const handleEdit = (student) => {
    setSelectedStudent(student);
    setShowEditComponent(true);
  };

  if (showEditComponent && selectedStudent) {
    return (
      <EditStudent
        student={selectedStudent}
        onClose={() => setShowEditComponent(false)}
        onSave={(updatedStudent) => {
          const updatedStudents = students.map((s) =>
            s.roll === updatedStudent.roll ? updatedStudent : s
          );
          setStudentData({ ...studentData, [classNameName]: updatedStudents });
          setShowEditComponent(false);
        }}
      />
    );
  }

  return (
    <div className="bg-green-700 min-h-screen p-2">
      <div className="bg-green-600 text-white text-lg font-semibold px-4 py-2 rounded-t">
        Manage {classNameName} Students
      </div>

      <div className="bg-green-100 p-3 rounded-b">
        <div className="flex justify-between items-center bg-green-50 p-3 rounded-t">
          <h2 className="font-semibold text-gray-700">{classNameName} List 🔄</h2>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1 bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm"
          >
            <Plus size={16} /> Add New
          </button>
        </div>

        <div className="overflow-x-auto mt-3 bg-white shadow rounded">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-gray-200 text-gray-700 text-left">
                <th className="p-2 border">Sr No</th>
                <th className="p-2 border">Student Name</th>
                <th className="p-2 border">Roll No</th>
                <th className="p-2 border">Admission No</th>
                <th className="p-2 border">Class(section)</th>
                <th className="p-2 border">Add Date</th>
                <th className="p-2 border">Action</th>
              </tr>
            </thead>
            <tbody>
              {currentStudents.map((student, index) => (
                <tr key={index} className="border-b hover:bg-gray-50 transition-colors">
                  <td className="p-2 border">{startIndex + index + 1}</td>
                  <td className="p-2 border">{student.name}</td>
                  <td className="p-2 border">{student.roll}</td>
                  <td className="p-2 border">{student.admission}</td>
                  <td className="p-2 border">
                    {classNameName.replace("Class", "").trim()}({student.section})
                  </td>
                  <td className="p-2 border">{student.date}</td>
                  <td className="p-2 border flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-blue-500 cursor-pointer" />
                    <Pencil
                      onClick={() => handleEdit(student)}
                      className="w-4 h-4 text-green-600 cursor-pointer"
                    />
                    <Trash2
                      onClick={() => handleDelete(index)}
                      className="w-4 h-4 text-red-500 cursor-pointer"
                    />
                  </td>
                </tr>
              ))}
              {currentStudents.length === 0 && (
                <tr>
                  <td colSpan="7" className="text-center py-4 text-gray-500">
                    No students found for {classNameName}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {students.length > 0 && (
          <div className="flex justify-between items-center mt-3 text-sm text-gray-600">
            <p>
              showing {startIndex + 1} to{" "}
              {Math.min(startIndex + itemsPerPage, students.length)} of{" "}
              {students.length} entries
            </p>
            <div className="flex items-center gap-1">
              <button
                className="px-2 py-1 border rounded disabled:opacity-50"
                onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                disabled={currentPage === 1}
              >
                Previous
              </button>
              {[...Array(totalPages)].map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentPage(i + 1)}
                  className={`px-2 py-1 border rounded ${currentPage === i + 1 ? "bg-blue-500 text-white" : "bg-white"
                    }`}
                >
                  {i + 1}
                </button>
              ))}
              <button
                className="px-2 py-1 border rounded disabled:opacity-50"
                onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Add Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-2 right-2 text-gray-500 hover:text-red-500"
            >
              <X />
            </button>
            <h3 className="text-lg font-semibold mb-4">Add New Student</h3>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Student Name"
                value={newStudent.name}
                onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                className="w-full border p-2 rounded"
              />
              <input
                type="text"
                placeholder="Roll No"
                value={newStudent.roll}
                onChange={(e) => setNewStudent({ ...newStudent, roll: e.target.value })}
                className="w-full border p-2 rounded"
              />
              <input
                type="text"
                placeholder="Admission No"
                value={newStudent.admission}
                onChange={(e) => setNewStudent({ ...newStudent, admission: e.target.value })}
                className="w-full border p-2 rounded"
              />
              <input
                type="text"
                placeholder="Class Section (e.g. A)"
                value={newStudent.section}
                onChange={(e) => setNewStudent({ ...newStudent, section: e.target.value })}
                className="w-full border p-2 rounded"
              />
              <input
                type="date"
                value={newStudent.date}
                onChange={(e) => setNewStudent({ ...newStudent, date: e.target.value })}
                className="w-full border p-2 rounded"
              />
            </div>
            <button
              onClick={handleAddStudent}
              className="mt-4 w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded"
            >
              Submit
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
