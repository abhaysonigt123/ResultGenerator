import { useState } from "react";
import Sidebar from "./components/Sidebar";
import StudentList from "./components/StudentList";
import Navbar from "./components/Navbar";
import EditStudentModal from "./components/EditStudent";

export default function App() {
  const [selectedClass, setSelectedClass] = useState(null);

  return (
    <div className="flex flex-col h-screen">
      {/* Full-width Navbar at top */}
      <Navbar />

      {/* Sidebar and Content below */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar onSelectClass={setSelectedClass} />

        {/* Main Content Area */}
        <main className="flex-1 bg-gray-100 overflow-y-auto" display="flex" justifyContent="center">
          {selectedClass ? (
            <StudentList classNameName={selectedClass} />
          ) : (
            <h2 className="text-gray-600 text-lg text-center ">
             Welcome! Please select a class from the sidebar.
            </h2>
          )}
        </main>
        
      </div>
     
    </div>
  );
}
